<?php 

return [
    'layout_name' => 'red',
	'layout_path' => 'layout',
    'module_path' => [
        'Application' => 'module/application'
    ]
];
