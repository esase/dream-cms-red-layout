Red layout

compatable:   2.2.x
version:      1.0.1
vendor:       eSASe
vendor_email: alexermashev@gmail.com

Included layouts and templates for:

    module: Application
    version: 2.2.0
    vendor:  eSASe
    vendor email: alexermashev@gmail.com