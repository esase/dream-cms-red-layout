<?php

return [
    'compatable' => '2.2.x',
    'version' => '1.0.1',
    'vendor' => 'eSASe',
    'vendor_email' => 'alexermashev@gmail.com'
];