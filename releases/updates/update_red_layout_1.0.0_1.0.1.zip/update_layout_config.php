<?php 

return [
    'layout_name' => 'red',
    'compatable' => '2.2.x',
    'version' => '1.0.1',
    'vendor' => 'eSASe',
    'vendor_email' => 'alexermashev@gmail.com',
	'layout_path' => 'layout',
    'module_path' => [
        'Application' => 'module/application'
    ]
];
